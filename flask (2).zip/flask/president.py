



from sklearn.feature_extraction.text import TfidfVectorizer
import pandas as pd


# Example, replace with your actual data loading code
data = pd.read_csv('president.csv')
tfidf_vectorizer = TfidfVectorizer(stop_words='english')
tfidf_matrix = tfidf_vectorizer.fit_transform(data['Skills'])

import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from sklearn.model_selection import train_test_split

# Assuming tfidf_matrix is your input data
X = tfidf_matrix.toarray()

# Split the data
X_train, X_test = train_test_split(X, test_size=0.2, random_state=42)

# Neural Network Architecture
model = Sequential([
    Dense(128, activation='relu', input_dim=X_train.shape[1]),
    Dropout(0.2),
    Dense(64, activation='relu'),
    Dropout(0.2),
    Dense(X_train.shape[1], activation='sigmoid')
])

model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# Model Summary
model.summary()

# Train the model
history = model.fit(X_train, X_train, epochs=20, batch_size=256, validation_data=(X_test, X_test), verbose=1)

from sklearn.metrics.pairwise import cosine_similarity

# Encode the skills using the trained model (you may want to use the encoder part only if you've designed an autoencoder)
encoded_skills = model.predict(X)

# Compute cosine similarity matrix
similarity_matrix = cosine_similarity(encoded_skills)

# Function to find most similar profiles
def get_similar_profiles(profile_index, top_n=1):
    similar_indices = np.argsort(similarity_matrix[profile_index])[::-1][1:top_n+1]
    return data.iloc[similar_indices]

# Example: Get top 5 similar profiles for the first profile
similar_profiles = get_similar_profiles(1000)
print(similar_profiles)