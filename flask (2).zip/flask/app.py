from flask import Flask, request, render_template, jsonify
import pandas as pd
import numpy as np
from president import get_similar_profiles  # Assuming this is correctly implemented
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/find_similars', methods=['POST'])
def find_similars():
    data = request.get_json()  # Correctly get JSON data from the request
    if not data or 'profile_index' not in data:
        return jsonify({'error': 'Missing profile_index'}), 400

    profile_index = data['profile_index']
    top_n = 1  # Adjust according to your needs
    similar_profiles = get_similar_profiles(int(profile_index), top_n)
    
    # Return the profiles as JSON or however you see fit
    # Example: Convert DataFrame to JSON if similar_profiles is a DataFrame
    return jsonify(similar_profiles.to_dict())

if __name__ == '__main__':
    app.run(debug=True, port=8000)

