from flask import Flask, request, render_template, jsonify
from exactchatbot import preprocess_input_sentence, respond_to_user  # Import your chatbot functions
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()
    if not data or 'message' not in data:
        return jsonify({'error': 'No message provided'}), 400

    message = data['message']
    response = respond_to_user(message)  # Use your chatbot function to get the response
    return jsonify({'response': response})

if __name__ == '__main__':
    app.run(debug=True, port=3000)
