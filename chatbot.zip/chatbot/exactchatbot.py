import json
import nltk
from nltk.stem import WordNetLemmatizer
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
import numpy as np

# Download NLTK resources
nltk.download('punkt')
nltk.download('wordnet')
nltk.download('omw-1.4')

# Load your JSON data
with open('dataset.json', 'r') as file:
    data = json.load(file)

# Initialize lemmatizer
lemmatizer = WordNetLemmatizer()

# Initialize tokenizer
tokenizer = Tokenizer(num_words=5000)
labels = []

# Data preparation
training_sentences = []
training_labels = []

# Fill in the lists with sentence and label data
for intent in data['intents']:
    for pattern in intent['patterns']:
        # Tokenize and lemmatize each sentence
        tokenized_sentence = nltk.word_tokenize(pattern)
        lemmatized_sentence = [lemmatizer.lemmatize(word.lower()) for word in tokenized_sentence]
        training_sentences.append(' '.join(lemmatized_sentence))

    if intent['tag'] not in labels:
        labels.append(intent['tag'])

tokenizer.fit_on_texts(training_sentences)
word_index = tokenizer.word_index

sequences = tokenizer.texts_to_sequences(training_sentences)
padded_sequences = pad_sequences(sequences, padding='post')

# Creating label encoder
label_index = dict((label, idx) for idx, label in enumerate(labels))
training_labels = [label_index[intent['tag']] for intent in data['intents'] for _ in intent['patterns']]
training_labels = np.array(training_labels)

from nltk.corpus import wordnet

def add_synonyms(sentence):
    words = nltk.word_tokenize(sentence)
    new_sentences = [sentence]

    for word in words:
        synonyms = set()
        for syn in wordnet.synsets(word):
            for lemma in syn.lemmas():
                synonyms.add(lemma.name().replace('_', ' '))  # Replace underscores for multi-word synonyms

        for synonym in synonyms:
            if synonym.lower() != word.lower():
                new_sentence = sentence.replace(word, synonym)
                new_sentences.append(new_sentence)

    return new_sentences

import nltk
from nltk.stem import WordNetLemmatizer
import re  # Regular expression library

# Initialize the lemmatizer
lemmatizer = WordNetLemmatizer()

# Assuming 'data' is your dataset and 'add_synonyms' is a function you've defined
training_sentences = []
labels = []

for intent in data['intents']:
    for pattern in intent['patterns']:
        # Add sentences with synonyms
        synonym_sentences = add_synonyms(pattern)

        for synonym_sentence in synonym_sentences:
            # Noise removal: remove non-alphabetic characters
            cleaned_sentence = re.sub(r'[^a-zA-Z\s]', '', synonym_sentence)

            # Tokenize the sentence
            tokenized_sentence = nltk.word_tokenize(cleaned_sentence)

            # Lemmatization and lowercasing for normalization
            lemmatized_sentence = [lemmatizer.lemmatize(word.lower()) for word in tokenized_sentence]

            # Add the processed sentence to training data
            training_sentences.append(' '.join(lemmatized_sentence))

    if intent['tag'] not in labels:
        labels.append(intent['tag'])



from wordcloud import WordCloud
import matplotlib.pyplot as plt

# Combine all the training sentences into one large string
all_sentences = ' '.join(training_sentences)

# Generate a word cloud image
wordcloud = WordCloud(width = 800, height = 400, background_color ='white').generate(all_sentences)

# Display the word cloud image
plt.figure(figsize=(10, 5))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis("off")
plt.show()

import nltk
from nltk.probability import FreqDist

# Tokenize all sentences
all_words = nltk.word_tokenize(all_sentences)

# Calculate frequency distribution
fdist = FreqDist(all_words)

# Plot the frequency distribution
fdist.plot(50, cumulative=False)  # Show the top 30 words

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, Dropout, Bidirectional
from tensorflow.keras.callbacks import EarlyStopping

# Assuming word_index and labels are already defined

model = Sequential([
    Embedding(len(word_index) + 1, 64),  # Increased embedding dimension
    Bidirectional(LSTM(64, return_sequences=True)),  # Bidirectional LSTM
    Dropout(0.5),  # Dropout for regularization
    LSTM(32),  # Additional LSTM layer
    Dense(64, activation='relu'),
    Dropout(0.5),  # Another dropout layer for regularization
    Dense(len(labels), activation='softmax')
])

model.compile(loss='sparse_categorical_crossentropy',
              optimizer='adam',
              metrics=['accuracy'])

# Early stopping callback
early_stopping = EarlyStopping(monitor='val_loss', patience=3)

# Train the model with validation split and early stopping
history = model.fit(padded_sequences, training_labels, epochs=200, verbose=1, validation_split=0.1, callbacks=[early_stopping])

import matplotlib.pyplot as plt

# Assuming 'history' is the output from the 'fit' call which contains the training history

# Summarize history for accuracy
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('Model accuracy')
plt.ylabel('Accuracy')
plt.xlabel('Epoch')
plt.legend(['Train', 'Validation'], loc='upper left')
plt.show()

# Summarize history for loss
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('Model loss')
plt.ylabel('Loss')
plt.xlabel('Epoch')
plt.legend(['Train', 'Validation'], loc='upper left')
plt.show()

import numpy as np

# Assuming you have already defined and trained 'model', 'tokenizer', and 'lemmatizer'

def preprocess_input_sentence(input_sentence):
    # Tokenize and lemmatize the input sentence
    tokenized_sentence = nltk.word_tokenize(input_sentence)
    lemmatized_sentence = [lemmatizer.lemmatize(word.lower()) for word in tokenized_sentence]
    # Convert the sentence to a sequence of integers
    sequence = tokenizer.texts_to_sequences([lemmatized_sentence])
    # Pad the sequence to the required input length of the model
    padded_sequence = pad_sequences(sequence, maxlen=padded_sequences.shape[1], padding='post')
    return padded_sequence

def respond_to_user(input_sentence):
    # Preprocess the input sentence
    padded_sequence = preprocess_input_sentence(input_sentence)
    # Predict the tag using the model
    prediction = model.predict(padded_sequence)
    # Find the tag with the highest prediction probability
    predicted_tag = labels[np.argmax(prediction)]
    # Retrieve a random response that corresponds to the predicted tag
    for intent in data['intents']:
        if intent['tag'] == predicted_tag:
            return np.random.choice(intent['responses'])

# The rest of your chat function remains the same



def chat():
    print("Chat with the bot (type 'quit' to stop)!")
    while True:
        user_input = input("You: ")
        if user_input.lower() == 'quit':
            break

        response = respond_to_user(user_input)
        print("Bot:", response)

# Start the chat session
chat()