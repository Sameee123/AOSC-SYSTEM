

import numpy as np
import pandas as pd
import sklearn
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)



from flask import Flask, request


from tabulate import tabulate

credits = pd.read_csv("credit_society.csv")

# Print the first five rows of the DataFrame in a tabular format
print(tabulate(credits.head(), headers='keys', tablefmt='psql'))

from tabulate import tabulate
societies = pd.read_csv("society_data.csv")

# Print the first five rows of the DataFrame in a tabular format
print(tabulate(societies.head(), headers='keys', tablefmt='psql'))

n_credits = len(credits)
n_societies = len(credits['Student_ID'].unique())
n_users = len(credits['Skills'].unique())

print(f"Number of credits: {n_credits}")
print(f"Number of unique StudentsId's: {n_societies}")
print(f"Number of unique users: {n_users}")
print(f"Average ratings per user: {round(n_credits/n_users, 2)}")
print(f"Average ratings per societies: {round(n_credits/n_societies, 2)}")

user_freq = credits[['Skills', 'Student_ID']].groupby(
	'Student_ID').count().reset_index()
user_freq.columns = ['Student_ID', 'n_credits']
print(user_freq.head())

# Find Lowest and Highest rated societies
mean_rating = credits.groupby('Student_ID')[['Communication']].mean()

lowest_rated = mean_rating['Communication'].idxmin()
societies.loc[societies['Student_ID'] == lowest_rated]

highest_rated = mean_rating['Communication'].idxmax()
societies.loc[societies['Student_ID'] == highest_rated]

credits[credits['Student_ID']==highest_rated]

credits[credits['Student_ID']==lowest_rated]


society_stats = credits.groupby('Student_ID')[['Communication']].agg(['count', 'mean'])
society_stats.columns = society_stats.columns.droplevel()

from scipy.sparse import csr_matrix

def create_matrix(df):

	N = len(df['Skills'].unique())
	M = len(df['Student_ID'].unique())

	# Map Ids to indices
	user_mapper = dict(zip(np.unique(df["Skills"]), list(range(N))))
	society_mapper = dict(zip(np.unique(df["Student_ID"]), list(range(M))))

	# Map indices to IDs
	user_inv_mapper = dict(zip(list(range(N)), np.unique(df["Skills"])))
	society_inv_mapper = dict(zip(list(range(M)), np.unique(df["Student_ID"])))

	user_index = [user_mapper[i] for i in df['Skills']]
	society_index = [society_mapper[i] for i in df['Student_ID']]

	X = csr_matrix((df["Communication"], (society_index, user_index)), shape=(M, N))

	return X, user_mapper, society_mapper, user_inv_mapper, society_inv_mapper

X, user_mapper, society_mapper, user_inv_mapper, society_inv_mapper = create_matrix(credits)

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

def plot_sparse_matrix(matrix, title="Matrix", xlabel="Skills", ylabel="Student ID"):
    plt.figure(figsize=(10, 10))

    # Convert the sparse matrix to a dense one for plotting
    matrix_dense = matrix.todense()

    # Create a heatmap
    sns.heatmap(matrix_dense, xticklabels=False, yticklabels=False, cmap="viridis", square=True)

    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.show()

# Assume you have already created your matrix X
plot_sparse_matrix(X, title="User-Item Interaction Matrix")

from sklearn.neighbors import NearestNeighbors
def find_similar_socities(Id, X, k, metric='cosine', show_distance=False):

	neighbour_ids = []

	society_ind = society_mapper[Id]
	society_vec = X[society_ind]
	k+=1
	kNN = NearestNeighbors(n_neighbors=k, algorithm="brute", metric=metric)
	kNN.fit(X)
	society_vec = society_vec.reshape(1,-1)
	neighbour = kNN.kneighbors(society_vec, return_distance=show_distance)
	for i in range(0,k):
		n = neighbour.item(i)
		neighbour_ids.append(society_inv_mapper[n])
	neighbour_ids.pop(0)
	return neighbour_ids


society_titles = dict(zip(societies['Student_ID'], societies['Title']))


Id=200


similar_ids = find_similar_socities(Id, X, k=4)
society_title = society_titles[Id]

print(f" Recommanded socities on based on your Id and this output preferd best society on your skills to apply   {society_title}")
for i in similar_ids:
	print(society_titles[i])

import numpy as np
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE

# Assuming X is your csr_matrix from earlier and society_mapper is defined
def visualize_societies(X, society_mapper, society_inv_mapper, Id):
    # Use t-SNE to project the data into two dimensions
    tsne = TSNE(n_components=2, random_state=0)
    X_tsne = tsne.fit_transform(X.toarray())  # Convert the sparse matrix to dense

    plt.figure(figsize=(12, 8))
    plt.scatter(X_tsne[:, 0], X_tsne[:, 1], alpha=0.5)

    # Highlight the society of interest
    target_ind = society_mapper[Id]
    plt.scatter(X_tsne[target_ind, 0], X_tsne[target_ind, 1], color='red', label='Target Society')

    # Highlight its similar societies
    similar_ids = find_similar_socities(Id, X, k=4)
    for similar_id in similar_ids:
        ind = society_mapper[similar_id]
        plt.scatter(X_tsne[ind, 0], X_tsne[ind, 1], color='green', label=society_inv_mapper[similar_id])

    plt.legend()
    plt.show()

# Call the function to visualize societies
visualize_societies(X, society_mapper, society_inv_mapper, Id)

def get_recommendations(Id):
    similar_ids = find_similar_socities(Id, X, k=4)
    recommendations = [society_titles[i] for i in similar_ids]
    return recommendations