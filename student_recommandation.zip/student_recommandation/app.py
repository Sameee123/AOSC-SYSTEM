from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
from reccommendation import get_recommendations  # Ensure this is the correct import

app = Flask(__name__)
CORS(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/recommend', methods=['POST'])
def recommend():
    data = request.get_json()  # Get data as JSON from the request body
    if not data or 'student_id' not in data:
        return jsonify({'error': 'Missing student ID'}), 400  # Return a JSON error message

    try:
        student_id = int(data['student_id'])  # Access the student_id from data
    except (ValueError, TypeError):
        return jsonify({'error': 'Invalid student ID'}), 400

    recommendations = get_recommendations(student_id)
    
    # Assuming get_recommendations returns a list of recommendations.
    # If it returns a DataFrame, convert to .to_dict(orient='records')
    return jsonify(recommendations)  # Return the recommendations as JSON

if __name__ == '__main__':
    app.run(debug=True, port=9000)
